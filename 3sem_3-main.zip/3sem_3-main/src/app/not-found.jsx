export default function NotFound(){
    return(
        <div>
            <h1>Oops!</h1>
            <h3>Sorry, an unexpected error has occurred</h3>
            <h5>Page not found</h5>
        </div>
    )
}